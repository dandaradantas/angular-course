export class Customer {
    constructor(
        public firstName: string,
        public lastName: string,
        public streetAddress: string,
        public fruit: Array<string>
    ) {}
}
